Some examples of card types that embed media from other sites :


* YouTube
* SoundCloud
* BandCamp
* Generica oEmbed. This is also pulling from soundcloud but note that it could be anywhere. The source of the data is specified in the :api argument.

----
:embed

{:type :youtube
 :url "https://www.youtube.com/watch?v=PsS29rEy07Y"}

----
:embed

{:type :soundcloud
 :url "https://soundcloud.com/mentufacturer/sets/muerck"}

----
:embed

{:type :bandcamp
 :id 3725429300
 :url "http://mentufacturer.bandcamp.com/album/muerck"
 :description "Muerck by Mentufacturer"
}

----
:embed

{:type :oembed
 :api "https://soundcloud.com/oembed"
 :url "https://soundcloud.com/mentufacturer/sets/fernanda-design-tree"
}


----
This is a place to play with wiki notation.

Does it now save?

----
:transclude 

{:from "HelloWorld"}
 


----

[[EmbeddingExamples]]

[[AboutThisWiki]]


[[EvalExamples]]

----

Editing again and again after moving gqlschema


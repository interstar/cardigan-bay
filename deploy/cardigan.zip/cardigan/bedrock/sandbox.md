This is a place to play with wiki notation.

----
:transclude 

{:from "HelloWorld"}
 


----

[[EmbeddingExamples]]



[[EvalExamples]]

----

Editing again and again after moving gqlschema
All pages in the wiki

----
:system

{:command :allpages}
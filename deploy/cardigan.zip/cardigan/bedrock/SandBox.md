This is a place to play with wiki notation.

Let's see if this saves now!

----
:transclude 

{:from "HelloWorld"}
 


----

[[EmbeddingExamples]]

[[AboutThisWiki]]


[[EvalExamples]]

----

Editing again and again after moving gqlschema


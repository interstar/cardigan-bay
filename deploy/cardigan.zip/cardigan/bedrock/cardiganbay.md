### This wiki is running in CardiganBay.

As you can see, each page is a sequence of cards.


Pretty feeble word-play, I agree. 

----

<img src="/cardigan-bay.svg" width="100%"/>
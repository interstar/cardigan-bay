java -jar ./cardigan.jar
